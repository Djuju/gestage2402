<?php

include_once 'include/lib/page/Onglet.php';
include_once 'include/lib/page/Menu.php';
include_once 'include/lib/page/Page.php';
include_once 'include/lib/page/PageFormulaire.php';
include_once 'include/lib/page/PageInformation.php';
include_once 'include/lib/page/PageListe.php';

?>