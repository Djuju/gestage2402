<?php

abstract class InputStringType
{
    const Any = 0;
    const Num = 1;
    const Alpha = 2;
    const AlphaNum = 3;
    const NumTelephone = 4;
    const AdresseMail = 5;
    const Url = 6;
    
    
}

?>