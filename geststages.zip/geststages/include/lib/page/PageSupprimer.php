﻿<?php

abstract class PageSupprimer extends Page
{
}
    


?>